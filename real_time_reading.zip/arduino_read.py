import sys, serial, argparse, csv, datetime
from time import sleep
    
BAUD = 9600
PORT = "/dev/cu.usbmodem1411"

def print_data(ser):
    line = ser.readline()
    data = [float(val) for val in line.split()]
    print(data)

def testCSV():
    csvfile = open('test_file.csv', 'ab')
    writer = csv.writer(csvfile, delimiter=',')
    data = ['1','2','3']
    writer.writerow(data)
    csvfile.close()


def writeToCSV(ser):
    # Your code goes here!
    pass
    

# main() function
def main():
    ser = serial.Serial(PORT, BAUD)
    try:
        while True:
            print_data(ser)
    except KeyboardInterrupt:
        print("Please don't leave!  Think of all the fun times we had together!")
    finally:
        ser.flush()
        ser.close()   

# call main
if __name__ == '__main__':
    main()
